type IconProps = {
  name: string;
  size?: number;
  filled?: boolean;
};

function Icon({ name, size = 20, filled = false }: IconProps) {
  const icons: Record<string, string> = {
    ship: "🚢",
    bell: "🔔",
    heart: filled ? "♥️" : "♡",
    map: "📍",
    pen: "✏️",
    comment: "💬",
    arrow: "→",
    chevron: "›",
    settings: "⚙️",
    anchor: "⚓",
    building: "🏢",
    port: "⚓",
    briefcase: "💼",
  };

  return (
    <span style={{ fontSize: size }}>
      {icons[name] ?? ""}
    </span>
  );
}

export default Icon;