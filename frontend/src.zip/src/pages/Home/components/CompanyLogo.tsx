interface CompanyLogoProps {
  code: string;
  compact?: boolean;
}

function CompanyLogo({ code, compact = false }: CompanyLogoProps) {
  return (
    <div className={`company-logo ${compact ? "company-logo-compact" : ""}`}>
      {code}
    </div>
  );
}

export default CompanyLogo;